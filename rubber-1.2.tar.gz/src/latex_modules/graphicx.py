# The 'graphics' and 'graphicx' packages are treated as equivalent.
def setup (document, context):
	document.do_module('graphics')
